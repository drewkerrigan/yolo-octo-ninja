### bear : a set of statistics functions for erlang

Currently bear is focused on use inside the Folsom Erlang metrics library but all of these functions are generic and useful in other situations.

Pull requests accepted!

#### Available under the Apache 2.0 License

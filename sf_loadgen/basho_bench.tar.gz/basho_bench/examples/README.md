README for examples
===================

Please see the source for the innostore and bitcask configuration files to see how to modify these config files to work properly in your
development or testing environment
